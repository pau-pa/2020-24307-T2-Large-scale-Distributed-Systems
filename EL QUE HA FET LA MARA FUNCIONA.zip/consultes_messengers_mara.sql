USE messengers;

/* Ex 1 */
SELECT cu.name
FROM customer AS cu, category AS ca
WHERE ca.name = "Farmacia" AND cu.category_id = ca.id
ORDER BY cu.name;

/* Ex 2 */
SELECT c.name AS NOM, p.name AS NOM_PARE
FROM category AS c, category AS p
WHERE (p.name = "Tecnologia" OR p.name = "Llibreria") AND p.id = c.parent_category_id;

/* Ex 3 */
SELECT c.name AS NOM, s.distance AS DIST
FROM customer AS c, serve AS s
WHERE s.office_id = 10 AND s.customer_id = c.id AND s.distance > 1000
ORDER BY s.distance ASC;

/* Ex 4 */
SELECT t.name AS TIPUS, COUNT(*) AS QUANTITAT
FROM vehicle AS v, type AS t
WHERE v.type_id = t.id
GROUP BY v.type_id
ORDER BY QUANTITAT DESC;

/* Ex 5 */
SELECT cu.name AS NEGOCI
FROM customer AS cu, driver AS d, serve AS s
WHERE cu.id= s.customer_id AND d.id = 10 AND d.office_id = s.office_id;

/* Ex 6 */
SELECT o.id AS ID, o.adress AS ADRESS, MIN(s.distance) AS DIST
FROM serve AS s, office AS o, category AS ca, customer AS cu
WHERE ca.name = "Restaurant" AND s.customer_id = cu.id AND s.office_id = o.id AND cu.category_id = ca.id;

/* Ex 7 */


/* Ex 8 */
SELECT cu.name AS NEGOCI, cu.latitude AS LATITUDE, cu.longitude AS LONGITUDE, type.name AS VEHICLE
FROM customer AS cu, vehicle as v, type, have, serve
WHERE type.number_of_wheels = 2 AND serve. customer_id = cu.id AND serve.office_id = have.office_id AND have.vehicle_id = v.id AND v.type_id = type.id
GROUP BY NEGOCI, VEHICLE
ORDER BY NEGOCI;

/* Ex 9 */


/* Ex 10 */
