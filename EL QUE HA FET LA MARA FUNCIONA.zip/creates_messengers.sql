DROP SCHEMA IF EXISTS messengers;
CREATE SCHEMA IF NOT EXISTS messengers;
USE messengers;

CREATE TABLE `office` (
	`id` int(2) NOT NULL DEFAULT '0',
    `latitude` float(10) DEFAULT NULL,
    `longitude` float(10) DEFAULT NULL,
    `adress` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
  
CREATE TABLE `driver` (
	`id` int(2) NOT NULL DEFAULT '0',
    `name` varchar(50) DEFAULT NULL,
    `office_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `vehicle` (
	`id` int(2) NOT NULL DEFAULT '0',
    `brand` varchar(20) DEFAULT NULL,
    `model` varchar(20) DEFAULT NULL,
    `capacity` int (10) DEFAULT NULL,
    `type_id` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `type` (
	`id` int(2) NOT NULL DEFAULT '0',
    `name` varchar(20) DEFAULT NULL,
    `number_of_wheels` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `customer` (
	`id` int(2) NOT NULL DEFAULT '0',
    `name` varchar(50) DEFAULT NULL,
    `latitude` float(10) DEFAULT NULL,
    `longitude` float(10) DEFAULT NULL,
    `adress` varchar(100) DEFAULT NULL,
    `category_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `category` (
	`id` int(2) NOT NULL DEFAULT '0',
    `name` varchar(50) DEFAULT NULL,
    `parent_category_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `serve` (
	`id` int(2) NOT NULL DEFAULT '0',
    `customer_id` int(2) DEFAULT NULL,
    `office_id` int(2) DEFAULT NULL,
    `distance` float(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `drive` (
	`id` int(2) NOT NULL DEFAULT '0',
    `driver_id` int(2) DEFAULT NULL,
    `type_id` int(2) DEFAULT NULL,
    `experience` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `have` (
	`id` int(4) NOT NULL DEFAULT '0',
    `vehicle_id` int(2) DEFAULT NULL,
    `office_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `office`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `driver`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_driver_office_id` (`office_id`);

ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_vehicle_type_id` (`type_id`);

ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);
  
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_customer_category_id` (`category_id`);
  
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_category_parent_category_id` (`parent_category_id`);
  
ALTER TABLE `serve`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_serve_customer_id` (`customer_id`),
  ADD KEY `fk_serve_office_id` (`office_id`);
  
ALTER TABLE `drive`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_drive_driver_id` (`driver_id`),
  ADD KEY `fk_drive_type_id` (`type_id`);
  
ALTER TABLE `have`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_have_vehicle_id` (`vehicle_id`),
  ADD KEY `fk_have_office_id` (`office_id`);


ALTER TABLE `driver`
  ADD CONSTRAINT `fk_driver_office_id` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`);

ALTER TABLE `vehicle`
  ADD CONSTRAINT `fk_vehicle_type_id` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`);
  
ALTER TABLE `customer`
  ADD CONSTRAINT `fk_customer_category_id` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

ALTER TABLE `category`
  ADD CONSTRAINT `fk_category_parent_category_id` FOREIGN KEY (`parent_category_id`) REFERENCES `category` (`id`);
  
ALTER TABLE `serve`
  ADD CONSTRAINT `fk_serve_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `fk_serve_office_id` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`);
  
ALTER TABLE `drive`
  ADD CONSTRAINT `fk_drive_driver_id` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`id`),
  ADD CONSTRAINT `fk_drive_type_id` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`);
  
ALTER TABLE `have`
  ADD CONSTRAINT `fk_have_vehicle_id` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicle` (`id`),
  ADD CONSTRAINT `fk_have_office_id` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`);
  




	